let ball;
let diameter = 20;
let radius = diameter / 2;
let speedX = 4;
let speedY = 4;

let initSize = 75;
let p1;
let p2;
let speedP = 4;

let bounce;
let hit;
let music;


function preload(){
  bounce = loadSound("raquetada.mp3");
  hit = loadSound("ponto.mp3");
  music = loadSound("trilha.mp3");
}

function setup() {
  createCanvas(600, 400);
  
  ball = {
    x : width / 2,
    y : height / 2
  };
  
  p1 = {
    x : 10,
    y : height / 2 - initSize / 2,
    size : initSize,
    points: 0
  };
  
  p2 = {
    x : width - 20,
    y : height / 2 - initSize / 2,
    size : initSize,
    points: 0
  };
  
  music.loop();
}

function draw() {
  background(0);
  ballDraw();
  ballMove();
  ballCollision();
  playerDraw();
  playerMove();
  playerOpMove();
  playerCollision();
  scoreboard();
  setPoints();
}


function ballDraw(){
  circle(ball.x, ball.y, diameter);
}
function ballMove(){
  ball.x += speedX;
  ball.y += speedY;
}
function ballCollision(){
  if( (ball.x > width - radius) || (ball.x < radius) ){ speedX *= -1; }
  if( (ball.y > height - radius) || (ball.y < radius) ){ speedY *= -1; }
}
function playerDraw(){
  rect(p1.x, p1.y, 10, p1.size);
  rect(p2.x, p2.y, 10, p2.size);
}
function playerMove(){
  if(keyIsDown(UP_ARROW)){p1.y -= speedP; }
  else if(keyIsDown(DOWN_ARROW)){p1.y += speedP; }
}
function playerOpMove(){
  if(keyIsDown(87)){p2.y -= speedP; }
  else if(keyIsDown(83)){p2.y += speedP; }
}
function playerCollision(){
  if( collideRectCircle(p1.x, p1.y, 10, p1.size, ball.x, ball.y, diameter) || 
      collideRectCircle(p2.x, p2.y, 10, p2.size, ball.x, ball.y, diameter) ){
    speedX *= -1;
    bounce.play();
  }
}
function scoreboard(){
  stroke(255);
  textSize(30);
  textAlign(CENTER);
  
  fill(color(255, 140, 0));
  rect(220, 15, 60, 30);
  fill("white");
  text(p1.points, 250, 40);
  
  fill(color(255, 140, 0));
  rect(320, 15, 60, 30);
  fill("white");
  text(p2.points, 350, 40);
}
function setPoints(){
  if(ball.x + radius > width-1){p1.points += 1; ball.x -= 1; hit.play();}
  else if(ball.x - radius < 0){p2.points += 1; ball.x += 1; hit.play();}
}